import { NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    console.log("🔥 ElevenLabs API route called")
    
    const { text, voice_id, language } = await request.json()

    console.log(`📝 Text: ${text.substring(0, 50)}...`)
    console.log(`🎤 Voice ID: ${voice_id}`)
    console.log(`🌍 Language: ${language}`)

    if (!process.env.ELEVENLABS_API_KEY) {
      console.error("❌ No ElevenLabs API key found")
      return NextResponse.json({ error: "API key not configured" }, { status: 500 })
    }

    console.log("🚀 Calling ElevenLabs API...")

    const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voice_id}`, {
      method: "POST",
      headers: {
        "Accept": "audio/mpeg",
        "Content-Type": "application/json",
        "xi-api-key": process.env.ELEVENLABS_API_KEY,
      },
      body: JSON.stringify({
        text: text,
        model_id: "eleven_multilingual_v2",
        voice_settings: {
          stability: 0.5,
          similarity_boost: 0.5,
          style: 0.5,
          use_speaker_boost: true
        },
      }),
    })

    console.log(`📡 ElevenLabs response status: ${response.status}`)

    if (!response.ok) {
      const errorText = await response.text()
      console.error("❌ ElevenLabs API error:", response.status, errorText)
      return NextResponse.json({ error: `ElevenLabs API error: ${errorText}` }, { status: response.status })
    }

    const audioBuffer = await response.arrayBuffer()
    console.log(`✅ Audio generated: ${audioBuffer.byteLength} bytes`)
    
    return new Response(audioBuffer, {
      headers: {
        "Content-Type": "audio/mpeg",
      },
    })
  } catch (error) {
    console.error("❌ Server error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}